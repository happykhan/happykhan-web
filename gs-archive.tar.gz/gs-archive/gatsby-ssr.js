import { wrapRootElement as wrap } from "./src/components/wrap-root-element"

export const wrapRootElement = wrap
